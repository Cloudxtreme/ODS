#!/bin/bash

currentSegment=0
currentLayer=0
amountSegment=0
layer[0]=0
layer[1]=0
layer[2]=0
layer[3]=0
max=3

rm compareOutput.txt


function writeCorrectLine()
{
	echo "inside writeCorrectLine"
	if [[ $max -lt 0 ]]; then
		echo "wrong: no base layer"
		if [[ `expr $currentSegment % 16` -eq 0 ]];then
			type="I"
			echo "true"
		else
			
			echo "false"
			echo "secondif: "
			if [[ `expr $currentSegment % 5` -eq 0 ]];then
				type="P"
				echo "true"
			else
				type="B"
				echo "false"
			fi
		fi
		echo "$currentSegment"";0;""$type"";0;0;0;0" >> compareOutput.txt
	else
		echo "correct"
		cat "layer"$max".txt"| sed -n $(echo "`expr $currentSegment + 1`""p") >> compareOutput.txt
	fi
}

prepareForNextSegment(){
	#the input segment is higher than the current segment

	if [[ $amountSegment -lt 4 ]]; then
		#we didn't get all the segments with this segment number
		#check which layer is the maximum layer we can use
		for i in {0..3}
		do
			echo "amtsegm: $amountSegment"
			echo "i: $i"
			if [[ ${layer[$i]} -ne 1 ]]; then
				#this is the first layer that wasn't present
				#the maximum enhancement we can use is one layer lower than this
								
				echo "layer[i]: ""${layer[$i]}"				
				max=`expr $i - 1`
				echo "$max"
				if [[ $max -lt 0 ]]; then
					#the base layer wasn't present!
					echo $currentSegment": no base layer!" >&2
				fi
				break
			fi
		done
		layer[0]=0
		layer[1]=0
		layer[2]=0
		layer[3]=0
	else
		#we got all the segments with the current segment number
		#so we've received all segments with the same number as the current segment number
		echo "all segments"
		max=3
		layer[0]=0
		layer[1]=0
		layer[2]=0
		layer[3]=0
		layer[${input[1]}]=1
	fi
	writeCorrectLine
	max=3
	((currentSegment++))
	amountSegment=1
	((currentLayer++))
}

while read -a input; do
  #input[0] = segment , input[1] = layer
echo "new"
echo " "
  if [[ input[0] -gt $currentSegment ]]; then #4>3
  
	prepareForNextSegment
	
  else
	#the input segment is not higher than the current segment
	((amountSegment++))
	layer[${input[1]}]=1
  fi 
  
done
prepareForNextSegment
